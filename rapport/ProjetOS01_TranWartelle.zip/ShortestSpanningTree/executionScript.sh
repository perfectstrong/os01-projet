#! bin/sh

./InputGenerator

for files in $(ls input/); do
    echo "$files"
    if [ "$files" != "input_10000_10_10.txt" ]; then
        echo "V0"
       ./SST_normal "./input/$files" "output/outputV0_$files"
        echo "V1"
       ./SST_improved "./input/$files" "output/outputV1_$files"
   fi
   echo "V2"
   ./SST_best "./input/$files" "output/outputV2_$files"
done

